var $FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
var $FullNameRegEx = /^([a-zA-Z ]{2,40})$/;
var $EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;
var $ConNoRegEx = /^([0-9]{10})$/;
var $AgeRegEx = /^([0-9]{1,2})$/;
$(document).ready(function(){
				
    $("#Firstname").blur(function(){
        $("#FirstnameValidate").empty();
        if($(this).val().trim()=="" || $(this).val().trim()==null)
        {
            $("#FirstnameValidate").html("(*) Firstname required plese enter..!!");
        }
        else{
            if(!$(this).val().trim().match($FNameLNameRegEx)){
                $("#FirstnameValidate").html("Invalid firstname..!!");
            }
        }
    });
    
    $("#Firstname").keypress(function(e){
        var ASCIIValue=e.which,Flag=false;
        
        $("#FirstnameValidate").empty();
        
        ((ASCIIValue>=65 && ASCIIValue<=90) || (ASCIIValue>=97 && ASCIIValue<=121))
            ?(Flag=true)
            :($("#tFirstnameValidate").html("Invalid input..!!"),Flag=false)

        return Flag;
    });
    
    $("#Lastname").keypress(function(e){
        
        var ASCIIValue=e.which,Flag=false;
        
        $("#LastnameValidate").empty();
        
        ((ASCIIValue>=65 && ASCIIValue<=90) || (ASCIIValue>=97 && ASCIIValue<=121))
            ?(Flag=true)
            :($("#LastnameValidate").html("Invalid input..!!"),Flag=false)

        return Flag;
    });
    $("#Lastname").blur(function(){
        $("#LastnameValidate").empty();
        if($(this).val().trim()=="" || $(this).val().trim()==null)
        {
            $("#LastnameValidate").html("(*) Lastname required..!!");
        }
        else{
            if(!$(this).val().trim().match($FNameLNameRegEx)){
                $("#LastnameValidate").html("Invalid lastname..!!");
            }
        }
    });
    
    $("#Emailid").blur(function(){
        $("#EmailidValidate").empty();
        if($(this).val().trim()=="" || $(this).val().trim()==null)
        {
            $("#EmailidValidate").html("(*) Email id required..!!");
        }
        else{
            if(!$(this).val().trim().match($EmailIdRegEx)){
                $("#EmailidValidate").html("Invalid emailid..!!");
            }
        }
    });
    
    $("#ContactNo").keypress(function(e){
        
        var ASCIIValue=e.which,Flag=false;
        
        $("#ContactNoValidate").empty();
        
        (ASCIIValue>=48 && ASCIIValue<=57)
            ?Flag=true
            :($("#ContactNoValidate").html("Invalid input..!!"),Flag=false)

        return Flag;
    });
    
    $("#ContactNo").blur(function(){
        $("#ContactNoValidate").empty();
        if($(this).val().trim()=="" || $(this).val().trim()==null)
        {
            $("#ContactNoValidate").html("(*) Contact no. required..!!");
        }
        else{
            if(!$(this).val().trim().match($ConNoRegEx)){
                $("#ContactNoValidate").html("Invalid contact no..!!");
            }
        }
    });
    $("#age").keypress(function(e){
        
        var A=e.which,Flag=false;
        
        $("#ageValidate").empty();
        
        (A=>100)
            ?Flag=true
            :($("#ageValidate").html("Invalid input..!!"),Flag=false)

        return Flag;
    });
    
    $("#age").blur(function(){
        $("#ageValidate").empty();
        if($(this).val().trim()=="" || $(this).val().trim()==null)
        {
            $("#ageValidate").html("(*) Contact no. required..!!");
        }
        else{
            if(!$(this).val().trim().match($ConNoRegEx)){
                $("#ageValidate").html("Invalid input..!!");
            }
        }
    });
    
    var FirstnameFlag=false,LastnameFlag=false,EmailidFlag=false,ContactNoFlag=false;
    $("#BtnCreateNewAccount").click(function(){
        $("#FirstnameValidate").empty();
        if($("#Firstname").val().trim()=="" || $("#Firstname").val().trim()==null)
        {
            $("#FirstnameValidate").html("(*) Firstname required..!!");
            FirstnameFlag=false;
        }
        else{
            if(!$("#Firstname").val().trim().match($FNameLNameRegEx)){
                $("#FirstnameValidate").html("Invalid firstname..!!");
                FirstnameFlag=false;
            }
            else{
                FirstnameFlag=true;
            }
        }	
        
        $("#LastnameValidate").empty();
        if($("#Lastname").val().trim()=="" || $("#Lastname").val().trim()==null)
        {
            $("#LastnameValidate").html("(*) Lastname required..!!");
            LastnameFlag=false;
        }
        else{
            if(!$("#Lastname").val().trim().match($FNameLNameRegEx)){
                $("#LastnameValidate").html("Invalid lastname..!!");
                LastnameFlag=false;
            }
            else{
                LastnameFlag=true;
            }
        }
        $("#EmailidValidate").empty();
        if($("#Emailid").val().trim()=="" || $("#Emailid").val().trim()==null)
        {
            $("#EmailidValidate").html("(*) Email id required..!!");
            EmailidFlag=false;
        }
        else{
            if(!$("#Emailid").val().trim().match($EmailIdRegEx)){
                $("#EmailidValidate").html("Invalid emailid..!!");
                EmailidFlag=false;
            }
            else{
                EmailidFlag=true;
            }
        }
        $("#ContactNoValidate").empty();
        if($("#ContactNo").val().trim()=="" || $("#ContactNo").val().trim()==null)
        {
            $("#ContactNoValidate").html("(*) Contact no. required..!!");
            ContactNoFlag=false;
        }
        else{
            if(!$("#ContactNo").val().trim().match($ConNoRegEx)){
                $("#ContactNoValidate").html("Invalid contact no..!!");
                ContactNoFlag=false;
            }
            else{
                ContactNoFlag=true;
            }
        }
        
        if(FirstnameFlag==true && LastnameFlag==true && EmailidFlag==true && ContactNoFlag==true)
        {
            alert("Form  Successfully submited..!!");
        }
        else{
            alert("Invalid Form Inputs..!!");

        }
        
    });
});